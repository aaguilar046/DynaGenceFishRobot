## Footprint update C1
Read FOOTPRINTS.md first. It supersedes the original provisional footprint and capacitor-dimension notes below. All electrical footprints are now bundled and assigned; heatsink hardware is still unresolved.

# Fixed 20 V/V Class A reference — Rev C

This revision supersedes the variable-gain drawing. No Raspberry Pi, SPI, I2C, digital potentiometer, 3.3 V supply, or ±12 V supply is used. Both OPA455 amplifiers operate directly from the main ±40 V rails. The Pi may supply the input through a suitable DAC or external analog source; its GPIO is not an analog output.

## Files / opening
Open fixed20.sch in KiCad Schematic Editor. This is a legacy-format editable schematic with local symbols and labeled connectivity; save it as .kicad_sch after import. Open fixed20.kicad_pcb separately in PCB Editor. Use the included project-local symbol and footprint tables. The board has an outline, component placement and assigned pad nets, but NO TRACKS OR COPPER ZONES. It is not a manufacturing-ready PCB. No Gerbers are supplied.

The custom symbol uses a rectangular functional block for each amplifier and transistor, with pin functions shown explicitly. The PNG provides a more conventional connected circuit drawing. Sch/PCB reference designators are synchronized; do not preserve the old Rev B designators.

## Circuit
U1 is a high-voltage differential receiver: R1=R3=2k and R2=R4=10k. PRE=5*(IN+ - IN-). U2 and Q1 form a noninverting gain-4 stage: R5=3k and R6=1k. Output isolation resistor R8=4.7 ohms is outside feedback. Overall low-frequency gain is 20 nominal, not guaranteed exact at 100 kHz. Input full scale is ±1.5 V differential for ±30 V output. No DC-blocking capacitors are used.

Q2 sinks about 0.23 A through R10=2.7 ohms. Q3 senses the emitter resistor and shunts Q2 base current. R9 biases the base from GND. Current depends on VBE, temperature, and base current. Q1 remains on for the expected 99 mA peak sine-wave load current. Q1/Q2 candidate MJE15032G need heatsinks, isolated tabs where appropriate, and DC SOA validation. Output stage idle dissipation is about 18.4 W, excluding amplifier/bias losses. OPA455 PowerPAD connects to -40 V, NEVER ground.

U1/U2 pin mapping: 1 ED_COM=GND; 2 IN-; 3 IN+; 4 V-=-40V; 5 STATUS left unconnected; 6 OUT; 7 V+=+40V; 8 ED left open (enabled by internal circuitry); 9 exposed pad=-40V. Confirm against current datasheet and exact package before production.

## Terminals
J1: 1 +40V; 2 GND; 3 -40V. J2: 1 IN+; 2 IN-; 3 GND. J3: 1 OUT; 2 GND. All are intended top-entry terminals. Their footprints are provisional 5.08 mm pitch generic geometry; choose actual vendor parts and validate dimensions, voltage ratings and wire entry direction. Never place a PCB order using provisional connector geometry.

## Required completion
- Open/import in KiCad, inspect symbol resolution and run ERC; native KiCad was unavailable during generation.
- Validate all footprints. OPA455 DDA thermal pad uses provisional 2.6 x 3.1 mm geometry; verify exact package variant, paste pattern and thermal copper. Capacitor body geometry and power resistor dimensions are placeholders pending actual MPNs.
- Q3 TO92 mapping provisionally uses E=1, B=2, C=3; verify the exact manufacturer part. Q1/Q2 use B=1, C=2, E=3.
- Reposition/reroute for short feedback, input symmetry, supply bypassing and heat dissipation. All nets are unrouted; placement is a planning aid, not optimized.
- Simulate output loop with transistor models, 5.25 nF plus cable capacitance. Check 100 kHz full-amplitude gain, phase, distortion, step response and oscillation margins.
- Add source and sink current limiting, thermal trips, reverse-BE/inductive-transient protection as justified, and safe power-up/down control. These are not implemented.
- Disabling a voltage amplifier alone is unsafe because the current sink remains active and can pull output toward the negative rail.
- Check sustained DC output and short-circuit transistor SOA; OPA455 internal current limiting does not protect the discrete output devices.
- Run PCB DRC after routing; validate electrical clearances for 80 V rail-to-rail plus transients.
- 60 Vpp into 5.25 nF at 100 kHz sine requires 99 mA peak and 18.85 V/us. The ideal capacitor absorbs no average real power; 5 W real load power is not established by capacitance alone.

## Sources
TI OPA455: https://www.ti.com/lit/ds/symlink/opa455.pdf
onsemi MJE15032: https://www.onsemi.com/download/data-sheet/pdf/mje15032-d.pdf
