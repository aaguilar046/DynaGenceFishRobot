# Footprint assignments — revision C1

Every one of the 24 electrical components has a real .kicad_mod footprint in Fixed20Footprints.pretty. The project-local fp-lib-table loads it. BOM.csv and schematic F2 fields specify identical names. The unrouted board has been updated to embed the new pad geometry and preserve existing net names.

Standard resistor, ceramic-capacitor, radial-capacitor and transistor footprints are adapted from KiCad/kicad-footprints. Older syntax has been converted to modern footprint syntax. 3D model references were removed because 3D models are not bundled; this does not affect copper pads or drilling. See KICAD_LIBRARY_LICENSE.md for CC-BY-SA and the design exception.

OPA455_DDA8_EP2.6x3.1 is a custom footprint based on the TI OPA455 DDA0008J example board layout: 1.27mm pitch, 1.55x0.6mm lead lands, and 2.6x3.1mm exposed pad. Four paste windows are supplied. Pad 9 is assigned to -40V, never GND. Confirm the package variant and assembly paste requirements before release.

KEFA_KF128-5.08-2P-AA and -3P-AA are custom footprints from the KEFA KF128 mechanical drawing: 5.08mm pitch, 1.4mm drill, nominal 10.5mm depth. These are not generic interchangeable terminal-block footprints. Check the actual part's entry direction and pin-1 orientation before ordering. Wire-entry direction has not been positively confirmed as the requested top entry.

Q1/Q2 use pin 1 base, 2 collector, 3 emitter. Q3 Semtech C596306 uses pin 1 emitter, 2 base, 3 collector. TO-92_Inline uses the unformed 1.27mm lead pitch; preformed lead variants need different footprints.

C5/C6 now use the selected 6.3mm-diameter, 2.5mm-pitch radial footprint. R5 is 1206; R8-R10 are 2512. This differs from the old generic reference pads.

HS_50x18mm_ENVELOPE_ONLY is a planning envelope for the provisional C4648 heatsink. It has no mounting holes or electrical pads, is not assigned to the board, and is NOT a production footprint. Heatsink thermal selection and hardware remain unresolved. No accurate mounting footprint is claimed for unspecified hardware.

Checks: all 24 schematic fields resolve to bundled files; every electrical pin matches footprint pads and board net assignment; footprint/board S-expression structure parses. Native KiCad is unavailable here, so these files have NOT passed native ERC/DRC or an interactive import test. The board remains unrouted and the amplifier remains electrically unverified.

Sources:
https://github.com/KiCad/kicad-footprints
https://www.ti.com/lit/ds/symlink/opa455.pdf
https://atta.szlcsc.com/upload/public/pdf/source/20200115/C474951_B988FDD36D11CB9BFE294AE1C4555C5E.pdf
https://atta.szlcsc.com/upload/public/pdf/source/20200608/C596306_0127940F2EBB8762CEDFFAC9A92F61CA.pdf
